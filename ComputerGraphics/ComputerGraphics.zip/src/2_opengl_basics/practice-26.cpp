#define CG_APPLICATION_CUSTOM_CALLBACK_KEY
#include <CG.h>

namespace
{
	std::optional<Shader> lightingShader{};
	std::optional<Shader> uniformColorShader{};

	Object axes{};
	Object cube{};

	Object trail{};
	Object pyramid{};

	Object lightCube{};
	Object lightCubeTrail{};

	Vec3 lightPos{ 0.0f, 0.0f, 2.0f };


	Timeline* rotateCube{};
	Timeline* rotatePyramid{};

	SpawnedNode lightCubeNode{};
	SpawnedNode trailNode{};

	bool enableLight{};
	bool renderPyramid{};
}

int main()
{
	Application app{ 1280, 960 };
	if (int code = app.Init("i hate computer graphics 7")) return code;
	glEnable(GL_DEPTH_TEST);
	app.Run();
}

void Application::OnInit()
{
	lightingShader.emplace("shaders/1_opengl_basics/projectionViewNormal.vs",
		"shaders/1_opengl_basics/pointPhongLight.fs");
	uniformColorShader.emplace("shaders/1_opengl_basics/projectionView.vs",
		"shaders/1_opengl_basics/uniformColor.fs");

	lightingShader->Bind();
	lightingShader->SetUniform("lightColor", Vec3{ 1.0f });
	AppendCamera(glm::vec3(0.0f, 10.0f, 0.0f));
	m_Cameras[0].FocusAt(Vec3{ 0.0f });

	lightCubeNode = lightCube.SpawnOpaque({ .file = "data/1_opengl_basics/cubePrimitive.obj",
		.color = Vec3{ 1.0f, 1.0f, 1.0f },.pos = lightPos, .scale = Vec3{0.5f}});

	auto cubeNode = cube.SpawnOpaque({ .file = "data/1_opengl_basics/cubePrimitive.obj",
	   .color = Vec3{ 0.0f, 1.0f, 0.0f }, .scale = Vec3{ 1.0f } });

	auto pyramidNode = pyramid.SpawnOpaque({ .file = "data/1_opengl_basics/pyramid.obj",
	   .color = Vec3{ 0.0f, 1.0f, 0.0f }, .scale = Vec3{ 2.0f } });

	trailNode = trail.SpawnOpaque({ .file = "data/1_opengl_basics/circle.obj",
		.color = Vec3{ 0.0f, 1.0f, 0.0f }, .drawingMode{ DrawingMode::Inherit } });


	auto& global = AnimationHandler::Global();

	auto rotateCubeID = global.SetRotateAnimation(360.0f, Vec3{ 0.0f, 1.0f, 0.0f });
	auto rotatePyramidID = global.SetRotateAnimation(360.0f, Vec3{ 0.0f, 1.0f, 0.0f });

	auto& cubeT = cube.CreateTimeline();
	auto& pyramidT = pyramid.CreateTimeline();

	cubeT.AddEntry().Append(rotateCubeID, cubeNode.nodeID, cubeNode.trs.r);
	pyramidT.AddEntry().Append(rotatePyramidID, pyramidNode.nodeID, pyramidNode.trs.r);

	rotateCube = &cubeT;
	rotatePyramid = &pyramidT;

}

void Application::Clear()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Application::Update()
{
	trailNode.EditScale(lightPos);
}

void Application::Render(const glm::mat4& viewMatrix, const glm::mat4& projectionMatrix, int cameraIdx)
{
	lightingShader->Bind();
	lightingShader->SetUniform("lightPos", Vec3{ viewMatrix * Vec4{ lightPos, 1.0f } });

	lightingShader->SetUniform("projection", projectionMatrix);
	lightingShader->SetUniform("view", viewMatrix);
	
	lightingShader->SetUniform("enableLight", enableLight);
	lightingShader->SetUniform("ambient", 0.2f);
	lightingShader->SetUniform("specularStrength", 0.0f);
	lightingShader->SetUniform("shininess", 1);

	if (renderPyramid)
	{
		pyramid.Render(*lightingShader, viewMatrix);
	}
	else
	{
		cube.Render(*lightingShader, viewMatrix);
	}

	lightCube.Render(*lightingShader, viewMatrix);

	uniformColorShader->Bind();
	uniformColorShader->SetUniform("projection", projectionMatrix);
	uniformColorShader->SetUniform("view", viewMatrix);

	glDisable(GL_DEPTH_TEST);
	trail.Render(*uniformColorShader, viewMatrix);
	glEnable(GL_DEPTH_TEST);
}

void Application::OnKeyEvent(int key, int action, int mods)
{
	if (action == GLFW_PRESS)
	{
		switch (key)
		{
		case GLFW_KEY_N:
			renderPyramid = !renderPyramid;
			break;
		case GLFW_KEY_M:
		{
			enableLight = !enableLight;
			break;
		}
		case GLFW_KEY_Q:
			glfwSetWindowShouldClose(m_Window, true);
			break;
		}
	}
}